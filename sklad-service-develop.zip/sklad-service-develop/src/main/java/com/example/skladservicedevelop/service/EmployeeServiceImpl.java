package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.EmployeeModel;
import com.example.skladservicedevelop.database.repository.EmployeeRepository;
import com.example.skladservicedevelop.dto.request.EmployeeRequest;
import com.example.skladservicedevelop.dto.response.EmployeeResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public EmployeeResponse create(EmployeeRequest request) {
        EmployeeModel employee = new EmployeeModel();
        employee.setFullName(request.getFullName());
        employee.setPosition(request.getPosition());
        employee.setRole(request.getRole());
        employee.setFullName(request.getFullName());
        employee.setLogin(request.getLogin());
        employee.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        employeeRepository.save(employee);
        return toResponse(employee);
    }

    @Override
    public EmployeeResponse update(Integer id, EmployeeRequest request) {
        EmployeeModel employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        employee.setFullName(request.getFullName());
        employee.setPosition(request.getPosition());
        employee.setRole(request.getRole());
        employee.setLogin(request.getLogin());
        employee.setFullName(request.getFullName());
        if (request.getPassword() != null && !request.getPassword().isEmpty()) {
            employee.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        }
        employeeRepository.save(employee);
        return toResponse(employee);
    }

    @Override
    public void delete(Integer id) {
        employeeRepository.deleteById(id);
    }

    @Override
    public EmployeeResponse getById(Integer id) {
        EmployeeModel employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        return toResponse(employee);
    }

    @Override
    public List<EmployeeResponse> getAll() {
        return employeeRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private EmployeeResponse toResponse(EmployeeModel employee) {
        EmployeeResponse response = new EmployeeResponse();
        response.setId(employee.getId());
        response.setFullName(employee.getFullName());
        response.setPosition(employee.getPosition());
        response.setRole(employee.getRole());
        response.setLogin(employee.getLogin());

        return response;
    }
}