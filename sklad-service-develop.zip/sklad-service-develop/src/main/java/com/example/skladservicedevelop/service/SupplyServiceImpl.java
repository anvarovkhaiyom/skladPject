package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.EmployeeModel;
import com.example.skladservicedevelop.database.model.ProductModel;
import com.example.skladservicedevelop.database.model.SupplierModel;
import com.example.skladservicedevelop.database.model.SupplyHistoryModel;
import com.example.skladservicedevelop.database.repository.EmployeeRepository;
import com.example.skladservicedevelop.database.repository.ProductRepository;
import com.example.skladservicedevelop.database.repository.SupplierRepository;
import com.example.skladservicedevelop.database.repository.SupplyHistoryRepository;
import com.example.skladservicedevelop.dto.request.SupplyItemRequest;
import com.example.skladservicedevelop.dto.request.SupplyRequest;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class SupplyServiceImpl implements SupplyService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final EmployeeRepository employeeRepository;
    private final SupplyHistoryRepository supplyHistoryRepository;

    public SupplyServiceImpl(ProductRepository productRepository,
                             SupplierRepository supplierRepository,
                             EmployeeRepository employeeRepository,
                             SupplyHistoryRepository supplyHistoryRepository) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
        this.employeeRepository = employeeRepository;
        this.supplyHistoryRepository = supplyHistoryRepository;
    }

    @Override
    @Transactional
    public void createSupply(SupplyRequest request) {

        SupplierModel supplier = null;
        if (request.getSupplierId() != null) {
            supplier = supplierRepository.findById(request.getSupplierId())
                    .orElseThrow(() -> new RuntimeException("Supplier not found"));
        }

        EmployeeModel employee = null;
        if (request.getEmployeeId() != null) {
            employee = employeeRepository.findById(request.getEmployeeId())
                    .orElseThrow(() -> new RuntimeException("Employee not found"));
        }

        for (SupplyItemRequest it : request.getItems()) {
            ProductModel product = productRepository.findByBarcode(it.getBarcode())
                    .orElseGet(() -> productRepository.findBySku(it.getSku())
                            .orElseThrow(() -> new RuntimeException("Товар не найден")));
            BigDecimal qty = it.getQuantity() != null ? it.getQuantity() : BigDecimal.ZERO;
            if (qty.compareTo(BigDecimal.ZERO) <= 0) {
                throw new RuntimeException("Quantity must be > 0");
            }

            BigDecimal costPrice = it.getCostPrice() != null ? it.getCostPrice() : product.getCostPrice();

            BigDecimal currentStock = product.getStockQuantity() != null ? product.getStockQuantity() : BigDecimal.ZERO;
            product.setStockQuantity(currentStock.add(qty));
            productRepository.save(product);

            SupplyHistoryModel sh = new SupplyHistoryModel();
            sh.setProduct(product);
            sh.setSupplier(supplier);
            sh.setEmployee(employee);
            sh.setQuantity(qty);
            sh.setCostPrice(costPrice);
            sh.setBarcode(product.getBarcode());
            sh.setSupplyDate(LocalDateTime.now());

            supplyHistoryRepository.save(sh);
        }
    }
}
