package com.example.skladservicedevelop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkladServiceDevelopApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkladServiceDevelopApplication.class, args);
    }

}
