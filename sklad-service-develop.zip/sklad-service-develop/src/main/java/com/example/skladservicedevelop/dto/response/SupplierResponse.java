package com.example.skladservicedevelop.dto.response;

import lombok.Data;

@Data
public class SupplierResponse {
    private Integer id;
    private String fullName;
    private String contacts;
}