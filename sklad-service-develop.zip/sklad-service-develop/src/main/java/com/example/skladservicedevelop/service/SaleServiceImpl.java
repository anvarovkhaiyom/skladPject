package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.*;
import com.example.skladservicedevelop.database.repository.*;
import com.example.skladservicedevelop.dto.request.PaymentRequest;
import com.example.skladservicedevelop.dto.request.SaleItemRequest;
import com.example.skladservicedevelop.dto.request.SaleRequest;
import com.example.skladservicedevelop.dto.response.PaymentResponse;
import com.example.skladservicedevelop.dto.response.SaleItemResponse;
import com.example.skladservicedevelop.dto.response.SaleResponse;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SaleServiceImpl implements SaleService {

    private final SaleRepository saleRepository;
    private final SaleItemRepository saleItemRepository;
    private final ProductRepository productRepository;
    private final ClientRepository clientRepository;
    private final EmployeeRepository employeeRepository;
    private final SalePaymentRepository salePaymentRepository;
    private final CurrencyRepository currencyRepository;

    public SaleServiceImpl(
            SaleRepository saleRepository,
            SaleItemRepository saleItemRepository,
            ProductRepository productRepository,
            ClientRepository clientRepository,
            EmployeeRepository employeeRepository,
            SalePaymentRepository salePaymentRepository,
            CurrencyRepository currencyRepository
    ) {
        this.saleRepository = saleRepository;
        this.saleItemRepository = saleItemRepository;
        this.productRepository = productRepository;
        this.clientRepository = clientRepository;
        this.employeeRepository = employeeRepository;
        this.salePaymentRepository = salePaymentRepository;
        this.currencyRepository = currencyRepository;
    }

    private SaleResponse toResponse(SaleModel sale) {
        SaleResponse resp = new SaleResponse();
        resp.setId(sale.getId());
        resp.setSaleDate(sale.getSaleDate());
        resp.setStatus(sale.getStatus());
        resp.setTotalAmount(sale.getTotalAmount());
        resp.setChangeAmount(sale.getChangeAmount());
        resp.setDocumentNumber(sale.getDocumentNumber());
        if (sale.getClient() != null) {
            resp.setClientId(sale.getClient().getId());
            resp.setClientName(sale.getClient().getFullName());
        }
        resp.setClientId(sale.getClient() != null ? sale.getClient().getId() : null);
        resp.setEmployeeId(sale.getEmployee() != null ? sale.getEmployee().getId() : null);

        List<SaleItemResponse> itemResponses = new ArrayList<>();
        if (sale.getItems() != null) {
            for (SaleItemModel si : sale.getItems()) {
                SaleItemResponse ir = new SaleItemResponse();
                ir.setProductId(si.getProduct().getId());
                ir.setProductName(si.getProduct().getName());
                ir.setQuantity(si.getQuantity());
                ir.setUnitPrice(si.getUnitPrice());
                ir.setTotalPrice(si.getTotalPrice());
                ir.setBoxCount(si.getBoxCount());
                itemResponses.add(ir);
            }
        }
        resp.setItems(itemResponses);

        List<PaymentResponse> paymentResponses = new ArrayList<>();
        if (sale.getPayments() != null) {
            for (SalePaymentModel pay : sale.getPayments()) {
                PaymentResponse pr = new PaymentResponse();
                pr.setMethod(pay.getMethod());
                pr.setAmount(pay.getAmount());
                pr.setCurrencyCode(pay.getCurrency() != null ? pay.getCurrency().getCode() : null);
                pr.setExchangeRate(pay.getExchangeRate());
                paymentResponses.add(pr);
            }
        }
        resp.setPayments(paymentResponses);

        return resp;
    }

    @Override
    @Transactional
    public SaleResponse createSale(SaleRequest request) {
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new RuntimeException("Нет товаров в продаже");
        }

        SaleModel sale = new SaleModel();
        sale.setSaleDate(LocalDateTime.now());
        sale.setStatus("completed");

        Integer lastId = saleRepository.findMaxId();
        int nextId = (lastId == null) ? 1 : lastId + 1;
        sale.setDocumentNumber(String.format("%07d", nextId));

        String currentLogin = org.springframework.security.core.context.SecurityContextHolder
                .getContext().getAuthentication().getName();

        EmployeeModel employee = employeeRepository.findByLogin(currentLogin)
                .orElseThrow(() -> new RuntimeException("Сотрудник с логином [" + currentLogin + "] не найден"));
        sale.setEmployee(employee);

        sale.setCarMark(request.getCarMark());
        sale.setCarNumber(request.getCarNumber());
        sale.setDriverName(request.getDriverName());

        if (request.getClientId() != null) {
            sale.setClient(clientRepository.findById(request.getClientId()).orElse(null));
        }

        BigDecimal totalAmountBase = BigDecimal.ZERO;
        List<SaleItemModel> items = new ArrayList<>();

        for (SaleItemRequest itemReq : request.getItems()) {
            ProductModel product = productRepository.findByBarcode(itemReq.getBarcode())
                    .orElseThrow(() -> new RuntimeException("Товар не найден: " + itemReq.getBarcode()));

            BigDecimal qty = itemReq.getQuantity();
            BigDecimal itemTotal = product.getSalePrice().multiply(qty);

            SaleItemModel si = new SaleItemModel();
            si.setSale(sale);
            si.setProduct(product);
            si.setQuantity(qty);
            si.setUnitPrice(product.getSalePrice());
            si.setTotalPrice(itemTotal);

            BigDecimal inBox = product.getItemsInBox() != null ? product.getItemsInBox() : BigDecimal.ONE;
            si.setBoxCount(qty.divide(inBox, 2, java.math.RoundingMode.HALF_UP));
            si.setItemsPerBoxAtSale(inBox);

            items.add(si);
            totalAmountBase = totalAmountBase.add(itemTotal);

            product.setStockQuantity(product.getStockQuantity().subtract(qty));
            productRepository.save(product);
        }

        sale.setItems(items);
        sale.setTotalAmount(totalAmountBase);

        BigDecimal totalPaidInBase = BigDecimal.ZERO;
        List<SalePaymentModel> payments = new ArrayList<>();

        if (request.getPayments() != null) {
            for (PaymentRequest pReq : request.getPayments()) {
                CurrencyModel currency = currencyRepository.findByCode(pReq.getCurrency())
                        .orElseThrow(() -> new RuntimeException("Валюта не найдена: " + pReq.getCurrency()));

                BigDecimal rate = (pReq.getRate() != null) ? pReq.getRate() : BigDecimal.ONE;
                totalPaidInBase = totalPaidInBase.add(pReq.getAmount().multiply(rate));

                SalePaymentModel payment = new SalePaymentModel();
                payment.setSale(sale);
                payment.setMethod(pReq.getMethod());
                payment.setAmount(pReq.getAmount());
                payment.setCurrency(currency);
                payment.setExchangeRate(rate);
                payments.add(payment);
            }
        }

        sale.setPayments(payments);
        sale.setChangeAmount(totalPaidInBase.subtract(totalAmountBase));

        if (totalPaidInBase.compareTo(totalAmountBase) < 0) {
            throw new RuntimeException("Недостаточно средств. Ожидалось: " + totalAmountBase + ", получено: " + totalPaidInBase);
        }

        return toResponse(saleRepository.save(sale));
    }

    @Override
    @Transactional
    public SaleResponse getById(Integer id) {
        SaleModel sale = saleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found"));

        SaleResponse resp = new SaleResponse();
        resp.setId(sale.getId());
        resp.setSaleDate(sale.getSaleDate());
        resp.setStatus(sale.getStatus());
        resp.setTotalAmount(sale.getTotalAmount());
        resp.setChangeAmount(sale.getChangeAmount());
        resp.setClientId(sale.getClient() != null ? sale.getClient().getId() : null);
        resp.setEmployeeId(sale.getEmployee() != null ? sale.getEmployee().getId() : null);
        if (sale.getClient() != null) {
            resp.setClientId(sale.getClient().getId());
            resp.setClientName(sale.getClient().getFullName());
        } else {
            resp.setClientName("Розничный покупатель");
        }
        List<SaleItemResponse> items = new ArrayList<>();
        if (sale.getItems() != null) {
            for (SaleItemModel si : sale.getItems()) {
                SaleItemResponse ir = new SaleItemResponse();
                ir.setProductId(si.getProduct().getId());
                ir.setProductName(si.getProduct().getName());
                ir.setQuantity(si.getQuantity());
                ir.setUnitPrice(si.getUnitPrice());
                ir.setTotalPrice(si.getTotalPrice());
                items.add(ir);
            }
        }
        resp.setItems(items);
        List<PaymentResponse> paymentResponses = new ArrayList<>();
        if (sale.getPayments() != null) {
            for (SalePaymentModel pay : sale.getPayments()) {
                PaymentResponse pr = new PaymentResponse();
                pr.setMethod(pay.getMethod());
                pr.setAmount(pay.getAmount());
                pr.setCurrencyCode(pay.getCurrency() != null ? pay.getCurrency().getCode() : null);
                pr.setExchangeRate(pay.getExchangeRate());
                paymentResponses.add(pr);
            }
        }
        resp.setPayments(paymentResponses);

        return resp;
    }

    @Override
    @Transactional
    public List<SaleResponse> getAll() {
        return saleRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }
}
