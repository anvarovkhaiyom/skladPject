package com.example.skladservicedevelop.database.repository;

import com.example.skladservicedevelop.database.model.ProductModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.LockModeType;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<ProductModel, Integer> {
    Optional<ProductModel> findByBarcode(String barcode);
    Optional<ProductModel> findBySku(String sku);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM ProductModel p WHERE p.id = :id")
    Optional<ProductModel> findByIdForUpdate(@Param("id") Integer id);
    @Query("SELECT MAX(p.id) FROM ProductModel p")
    Integer findMaxId();
}
