package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.dto.request.SaleRequest;
import com.example.skladservicedevelop.dto.response.SaleResponse;

import java.util.List;

public interface SaleService {
    SaleResponse createSale(SaleRequest request);
    SaleResponse getById(Integer id);
    List<SaleResponse> getAll();
}