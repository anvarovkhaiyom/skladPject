package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.dto.request.SupplyRequest;

public interface SupplyService {
    void createSupply(SupplyRequest request);
}