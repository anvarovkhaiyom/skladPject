package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.SaleItemModel;
import com.example.skladservicedevelop.database.model.SaleModel;
import com.example.skladservicedevelop.database.repository.SaleRepository;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final SaleRepository saleRepository;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private final DateTimeFormatter longFormatter = DateTimeFormatter.ofPattern("dd MMMM yyyy", new Locale("ru"));

    private CellStyle headerStyle;
    private CellStyle dataStyle;
    private CellStyle titleStyle;
    private CellStyle currencyStyle;

    @Override
    public byte[] generatePickingListExcel(Integer saleId) {
        SaleModel sale = getSale(saleId);
        try (Workbook workbook = new XSSFWorkbook()) {
            initStyles(workbook);
            Sheet sheet = workbook.createSheet("Лист сборки");

            createTitle(sheet, 0, "Лист сборки для заказа № " + getDocNumber(sale));
            createRowKeyValue(sheet, 2, "Клиент:", getClientName(sale));
            createRowKeyValue(sheet, 3, "Дата:", sale.getSaleDate().format(formatter));

            String[] headers = {"№", "Артикул (SKU)", "Название", "Коробок", "Штук всего", "Ед. изм"};
            createTableHeader(sheet, 5, headers);

            int rowIdx = 6;
            int npp = 1;
            for (SaleItemModel item : sale.getItems()) {
                Row row = sheet.createRow(rowIdx++);
                createCell(row, 0, npp++, dataStyle);
                createCell(row, 1, item.getProduct().getSku(), dataStyle);
                createCell(row, 2, item.getProduct().getName(), dataStyle);
                createCell(row, 3, item.getBoxCount().doubleValue(), dataStyle);
                createCell(row, 4, item.getQuantity().doubleValue(), dataStyle);
                createCell(row, 5, item.getProduct().getUnit(), dataStyle);
            }

            autoSizeColumns(sheet, headers.length);
            return workbookToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Ошибка генерации", e);
        }
    }

    @Override
    public byte[] generateInvoiceWithBoxesExcel(Integer saleId) {
        SaleModel sale = getSale(saleId);
        try (Workbook workbook = new XSSFWorkbook()) {
            initStyles(workbook);
            Sheet sheet = workbook.createSheet("Накладная");
            String title = String.format("Расходная накладная № %s от %s", getDocNumber(sale), sale.getSaleDate().format(longFormatter));
            createTitle(sheet, 0, title);
            createRowKeyValue(sheet, 2, "Поставщик:", "Наш Склад (БИН 123456789)");
            createRowKeyValue(sheet, 3, "Покупатель:", getClientName(sale));
            createRowKeyValue(sheet, 4, "Водитель:", sale.getDriverName());
            String[] headers = {"№", "Код", "Товар", "В коробке", "Коробок", "Всего шт", "Цена", "Сумма"};
            createTableHeader(sheet, 6, headers);

            int rowIdx = 7;
            int npp = 1;
            for (SaleItemModel item : sale.getItems()) {
                Row row = sheet.createRow(rowIdx++);
                createCell(row, 0, npp++, dataStyle);
                createCell(row, 1, item.getProduct().getSku(), dataStyle);
                createCell(row, 2, item.getProduct().getName(), dataStyle);
                createCell(row, 3, item.getItemsPerBoxAtSale(), dataStyle);
                createCell(row, 4, item.getBoxCount(), dataStyle);
                createCell(row, 5, item.getQuantity(), dataStyle);
                createCell(row, 6, item.getUnitPrice(), currencyStyle);
                createCell(row, 7, item.getTotalPrice(), currencyStyle);
            }

            rowIdx++;
            Row totalRow = sheet.createRow(rowIdx);
            createCell(totalRow, 6, "ИТОГО:", headerStyle);
            createCell(totalRow, 7, sale.getTotalAmount(), currencyStyle);

            rowIdx += 3;
            createRowKeyValue(sheet, rowIdx, "Отпустил:", getEmployeeName(sale) + " _______________");
            createRowKeyValue(sheet, rowIdx + 2, "Получил:", "_______________");

            autoSizeColumns(sheet, headers.length);
            return workbookToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Ошибка генерации накладной", e);
        }
    }

    @Override
    public byte[] generateZ2Report(Integer saleId) {
        SaleModel sale = getSale(saleId);
        try (Workbook workbook = new XSSFWorkbook()) {
            initStyles(workbook);
            Sheet sheet = workbook.createSheet("З-2");

            createTitle(sheet, 0, "НАКЛАДНАЯ НА ОТПУСК ЗАПАСОВ НА СТОРОНУ (З-2)");

            createRowKeyValue(sheet, 2, "Номер документа:", getDocNumber(sale));
            createRowKeyValue(sheet, 3, "Дата составления:", sale.getSaleDate().format(formatter));

            createRowKeyValue(sheet, 5, "Организация-получатель:", getClientName(sale));
            createRowKeyValue(sheet, 6, "Ответственный за поставку:", getEmployeeName(sale));

            String[] headers = {"№", "Наименование", "Номенкл. номер", "Ед. изм", "Подлежит отпуску", "Отпущено", "Цена", "Сумма"};
            createTableHeader(sheet, 8, headers);

            int rowIdx = 9;
            int npp = 1;
            for (SaleItemModel item : sale.getItems()) {
                Row row = sheet.createRow(rowIdx++);
                createCell(row, 0, npp++, dataStyle);
                createCell(row, 1, item.getProduct().getName(), dataStyle);
                createCell(row, 2, item.getProduct().getSku(), dataStyle);
                createCell(row, 3, item.getProduct().getUnit(), dataStyle);
                createCell(row, 4, item.getQuantity(), dataStyle);
                createCell(row, 5, item.getQuantity(), dataStyle);
                createCell(row, 6, item.getUnitPrice(), currencyStyle);
                createCell(row, 7, item.getTotalPrice(), currencyStyle);
            }

            rowIdx++;
            Row wordsRow = sheet.createRow(rowIdx);
            Cell cell = wordsRow.createCell(1);
            cell.setCellValue("Всего отпущено запасов на сумму: " + convertAmountToWords(sale.getTotalAmount()));

            autoSizeColumns(sheet, headers.length);
            return workbookToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Ошибка З-2", e);
        }
    }
    @Override
    public byte[] generateTTN(Integer saleId) {
        SaleModel sale = getSale(saleId);
        try (Workbook workbook = new XSSFWorkbook()) {
            initStyles(workbook);
            Sheet sheet = workbook.createSheet("ТТН");

            createTitle(sheet, 0, "ТОВАРНО-ТРАНСПОРТНАЯ НАКЛАДНАЯ № " + getDocNumber(sale));

            createRowKeyValue(sheet, 2, "Грузоотправитель:", "Наш Склад");
            createRowKeyValue(sheet, 3, "Грузополучатель:", getClientName(sale));
            createRowKeyValue(sheet, 4, "Плательщик:", getClientName(sale));

            String carInfo = (sale.getCarMark() != null ? sale.getCarMark() : "") + " " + (sale.getCarNumber() != null ? sale.getCarNumber() : "");
            createRowKeyValue(sheet, 6, "Автомобиль:", carInfo);
            createRowKeyValue(sheet, 7, "Водитель:", sale.getDriverName());

            String[] headers = {"№", "Код груза", "Наименование", "Ед. изм", "Кол-во мест", "Масса (т)", "Кол-во", "Цена", "Сумма"};
            createTableHeader(sheet, 9, headers);

            int rowIdx = 10;
            int npp = 1;
            for (SaleItemModel item : sale.getItems()) {
                Row row = sheet.createRow(rowIdx++);
                createCell(row, 0, npp++, dataStyle);
                createCell(row, 1, item.getProduct().getSku(), dataStyle);
                createCell(row, 2, item.getProduct().getName(), dataStyle);
                createCell(row, 3, item.getProduct().getUnit(), dataStyle);
                createCell(row, 4, item.getBoxCount(), dataStyle);

                double weight = (item.getProduct().getWeightBrutto() != null)
                        ? item.getProduct().getWeightBrutto() * item.getQuantity().doubleValue()
                        : 0.0;
                createCell(row, 5, weight, dataStyle);

                createCell(row, 6, item.getQuantity(), dataStyle);
                createCell(row, 7, item.getUnitPrice(), currencyStyle);
                createCell(row, 8, item.getTotalPrice(), currencyStyle);
            }

            rowIdx++;
            createRowKeyValue(sheet, rowIdx, "Итого сумма:", convertAmountToWords(sale.getTotalAmount()));

            autoSizeColumns(sheet, headers.length);
            return workbookToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Ошибка ТТН", e);
        }
    }




    private void initStyles(Workbook wb) {
        headerStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);

        dataStyle = wb.createCellStyle();
        dataStyle.setBorderBottom(BorderStyle.THIN);
        dataStyle.setBorderTop(BorderStyle.THIN);
        dataStyle.setBorderRight(BorderStyle.THIN);
        dataStyle.setBorderLeft(BorderStyle.THIN);
        dataStyle.setAlignment(HorizontalAlignment.LEFT);

        titleStyle = wb.createCellStyle();
        Font titleFont = wb.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 14);
        titleStyle.setFont(titleFont);

        currencyStyle = wb.createCellStyle();
        currencyStyle.cloneStyleFrom(dataStyle);
        currencyStyle.setDataFormat(wb.createDataFormat().getFormat("#,##0.00"));
    }

    private void createTitle(Sheet sheet, int rowIdx, String text) {
        Row row = sheet.createRow(rowIdx);
        Cell cell = row.createCell(0);
        cell.setCellValue(text);
        cell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 5));
    }

    private void createRowKeyValue(Sheet sheet, int rowIdx, String key, String value) {
        Row row = sheet.createRow(rowIdx);
        Cell cellKey = row.createCell(0);
        cellKey.setCellValue(key);
        CellStyle bold = sheet.getWorkbook().createCellStyle();
        Font f = sheet.getWorkbook().createFont();
        f.setBold(true);
        bold.setFont(f);
        cellKey.setCellStyle(bold);

        Cell cellValue = row.createCell(1);
        cellValue.setCellValue(value != null ? value : "");
    }

    private void createTableHeader(Sheet sheet, int rowIdx, String[] headers) {
        Row row = sheet.createRow(rowIdx);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
    }

    private void createCell(Row row, int colIdx, Object value, CellStyle style) {
        Cell cell = row.createCell(colIdx);
        cell.setCellStyle(style);
        if (value instanceof Number) {
            cell.setCellValue(((Number) value).doubleValue());
        } else {
            cell.setCellValue(value != null ? value.toString() : "");
        }
    }

    private void autoSizeColumns(Sheet sheet, int count) {
        for (int i = 0; i < count; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private SaleModel getSale(Integer id) {
        return saleRepository.findById(id).orElseThrow(() -> new RuntimeException("Продажа не найдена"));
    }

    private String getClientName(SaleModel sale) {
        return (sale.getClient() != null) ? sale.getClient().getFullName() : "Розничный покупатель";
    }

    private String getEmployeeName(SaleModel sale) {
        return (sale.getEmployee() != null) ? sale.getEmployee().getFullName() : "";
    }

    private String getDocNumber(SaleModel sale) {
        return (sale.getDocumentNumber() != null) ? sale.getDocumentNumber() : String.valueOf(sale.getId());
    }

    private byte[] workbookToBytes(Workbook wb) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);
        return out.toByteArray();
    }

    private String convertAmountToWords(BigDecimal amount) {
        if (amount == null) return "0 тенге";
        return amount.toString() + " тенге";
    }
}