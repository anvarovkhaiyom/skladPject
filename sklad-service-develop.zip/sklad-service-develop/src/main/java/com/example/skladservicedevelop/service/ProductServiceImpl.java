package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.CategoryModel;
import com.example.skladservicedevelop.database.model.ProductModel;
import com.example.skladservicedevelop.database.repository.CategoryRepository;
import com.example.skladservicedevelop.database.repository.ProductRepository;
import com.example.skladservicedevelop.dto.request.ProductRequest;
import com.example.skladservicedevelop.dto.response.ProductResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public ProductServiceImpl(ProductRepository productRepository,
                              CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    @Override
    public ProductResponse create(ProductRequest request) {
        ProductModel product = new ProductModel();
        product.setName(request.getName());
        product.setCostPrice(request.getCostPrice());
        product.setUnit(request.getUnit());
        product.setSalePrice(request.getSalePrice());
        product.setStockQuantity(request.getStockQuantity());
        product.setBarcode(request.getBarcode());
        product.setPhotoUrl(request.getPhotoUrl());

        if (request.getSku() == null || request.getSku().isEmpty()) {
            Integer lastId = productRepository.findMaxId();
            int nextId = (lastId == null) ? 1 : lastId + 1;
            product.setSku(String.format("НФ-%07d", nextId));
        } else {
            product.setSku(request.getSku());
        }

        product.setItemsInBox(request.getItemsInBox());
        product.setWeightBrutto(request.getWeightBrutto());

        if (request.getCategoryId() != null) {
            CategoryModel category = categoryRepository.findById(request.getCategoryId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
            product.setCategory(category);
        }

        productRepository.save(product);
        return toResponse(product);
    }

    @Override
    public ProductResponse update(Integer id, ProductRequest request) {
        ProductModel product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        product.setName(request.getName());
        product.setCostPrice(request.getCostPrice());
        product.setUnit(request.getUnit());
        product.setSalePrice(request.getSalePrice());
        product.setStockQuantity(request.getStockQuantity());
        product.setBarcode(request.getBarcode());
        product.setPhotoUrl(request.getPhotoUrl());
        product.setSku(request.getSku());
        product.setItemsInBox(request.getItemsInBox());

        product.setWeightBrutto(request.getWeightBrutto());

        if (request.getCategoryId() != null) {
            CategoryModel category = categoryRepository.findById(request.getCategoryId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
            product.setCategory(category);
        }

        productRepository.save(product);
        return toResponse(product);
    }
    @Override
    public void delete(Integer id) {
        productRepository.deleteById(id);
    }

    @Override
    public ProductResponse getById(Integer id) {
        ProductModel product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        return toResponse(product);
    }

    @Override
    public List<ProductResponse> getAll() {
        return productRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }
    private ProductResponse toResponse(ProductModel product) {
        ProductResponse response = new ProductResponse();
        response.setId(product.getId());
        response.setCategoryId(product.getCategory() != null ? product.getCategory().getId() : null);
        response.setName(product.getName());
        response.setSku(product.getSku());
        response.setWeightBrutto(product.getWeightBrutto());
        response.setItemsInBox(product.getItemsInBox());
        response.setCostPrice(product.getCostPrice());
        response.setUnit(product.getUnit());
        response.setSalePrice(product.getSalePrice());
        response.setStockQuantity(product.getStockQuantity());
        response.setBarcode(product.getBarcode());
        response.setPhotoUrl(product.getPhotoUrl());
        return response;
    }
}