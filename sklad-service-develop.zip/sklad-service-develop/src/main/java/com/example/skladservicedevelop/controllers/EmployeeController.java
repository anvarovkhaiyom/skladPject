package com.example.skladservicedevelop.controllers;

import com.example.skladservicedevelop.dto.request.SaleRequest;
import com.example.skladservicedevelop.dto.response.SaleResponse;
import com.example.skladservicedevelop.dto.request.SupplyRequest;
import com.example.skladservicedevelop.service.SaleService;
import com.example.skladservicedevelop.service.SupplyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    private final SaleService saleService;
    private final SupplyService supplyService;

    public EmployeeController(SaleService saleService, SupplyService supplyService) {
        this.saleService = saleService;
        this.supplyService = supplyService;
    }

    // SALES
    @PostMapping("/sale")
    public ResponseEntity<SaleResponse> createSale(@RequestBody SaleRequest request) {
        SaleResponse response = saleService.createSale(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/sale/{id}")
    public ResponseEntity<SaleResponse> getSale(@PathVariable Integer id) {
        SaleResponse response = saleService.getById(id);
        return ResponseEntity.ok(response);
    }

    // SUPPLY
    @PostMapping("/supply")
    public ResponseEntity<String> createSupply(@RequestBody SupplyRequest request) {
        supplyService.createSupply(request);
        return ResponseEntity.ok("Supply recorded successfully");
    }
}
