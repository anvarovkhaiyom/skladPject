package com.example.skladservicedevelop.service;

public interface ReportService {
    byte[] generatePickingListExcel(Integer saleId);
    byte[] generateInvoiceWithBoxesExcel(Integer saleId);
    byte[] generateZ2Report(Integer saleId);
    byte[] generateTTN(Integer saleId);
}