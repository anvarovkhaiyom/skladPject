package com.example.skladservicedevelop.dto.request;

import lombok.Data;

@Data
public class SupplierRequest {
    private String fullName;
    private String contacts;
}