package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.ClientModel;
import com.example.skladservicedevelop.database.repository.ClientRepository;
import com.example.skladservicedevelop.dto.request.ClientRequest;
import com.example.skladservicedevelop.dto.response.ClientResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientServiceImpl implements ClientService {

    private final ClientRepository clientRepository;

    public ClientServiceImpl(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    @Override
    public ClientResponse create(ClientRequest request) {
        ClientModel client = new ClientModel();
        client.setFullName(request.getFullName());
        client.setContacts(request.getContacts());
        clientRepository.save(client);
        return toResponse(client);
    }

    @Override
    public ClientResponse update(Integer id, ClientRequest request) {
        ClientModel client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));
        client.setFullName(request.getFullName());
        client.setContacts(request.getContacts());
        clientRepository.save(client);
        return toResponse(client);
    }

    @Override
    public void delete(Integer id) {
        clientRepository.deleteById(id);
    }

    @Override
    public ClientResponse getById(Integer id) {
        ClientModel client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));
        return toResponse(client);
    }

    @Override
    public List<ClientResponse> getAll() {
        return clientRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private ClientResponse toResponse(ClientModel client) {
        ClientResponse response = new ClientResponse();
        response.setId(client.getId());
        response.setFullName(client.getFullName());
        response.setContacts(client.getContacts());
        return response;
    }
}
