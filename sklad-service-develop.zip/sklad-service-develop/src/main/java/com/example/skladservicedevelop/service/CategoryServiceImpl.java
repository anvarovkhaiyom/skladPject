package com.example.skladservicedevelop.service;

import com.example.skladservicedevelop.database.model.CategoryModel;
import com.example.skladservicedevelop.database.repository.CategoryRepository;
import com.example.skladservicedevelop.dto.request.CategoryRequest;
import com.example.skladservicedevelop.dto.response.CategoryResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public CategoryResponse create(CategoryRequest request) {
        CategoryModel category = new CategoryModel();
        category.setName(request.getName());
        categoryRepository.save(category);
        return toResponse(category);
    }

    @Override
    public CategoryResponse update(Integer id, CategoryRequest request) {
        CategoryModel category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setName(request.getName());
        categoryRepository.save(category);
        return toResponse(category);
    }

    @Override
    public void delete(Integer id) {
        categoryRepository.deleteById(id);
    }

    @Override
    public CategoryResponse getById(Integer id) {
        CategoryModel category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        return toResponse(category);
    }

    @Override
    public List<CategoryResponse> getAll() {
        return categoryRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private CategoryResponse toResponse(CategoryModel category) {
        CategoryResponse response = new CategoryResponse();
        response.setId(category.getId());
        response.setName(category.getName());
        return response;
    }
}
