package com.example.skladservicedevelop.database.model;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "products")
@Data
public class ProductModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private CategoryModel category;

    @Column(nullable = false)
    private String name;

    @Column(name = "cost_price", nullable = false)
    private BigDecimal costPrice;

    @Column(nullable = false)
    private String unit;

    @Column(name = "sale_price", nullable = false)
    private BigDecimal salePrice;

    @Column(name = "stock_quantity", nullable = false)
    private BigDecimal stockQuantity;

    @Column(unique = true)
    private String barcode;

    @Column(name = "photo_url")
    private String photoUrl;

    @OneToMany(mappedBy = "product")
    private List<SaleItemModel> saleItems;

    @OneToMany(mappedBy = "product")
    private List<SupplyHistoryModel> supplyHistory;
    @Column(name = "sku", unique = true)
    private String sku;

    @Column(name = "items_in_box")
    private BigDecimal itemsInBox;

    @Column(name = "weight_brutto")
    private Double weightBrutto;
}
