package com.example.skladservicedevelop.database.repository;

import com.example.skladservicedevelop.database.model.SaleModel;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SaleRepository extends JpaRepository<SaleModel, Integer> {
    List<SaleModel> findBySaleDateBetween(LocalDateTime start, LocalDateTime end);
    @Query("SELECT MAX(s.id) FROM SaleModel s")
    Integer findMaxId();
}
