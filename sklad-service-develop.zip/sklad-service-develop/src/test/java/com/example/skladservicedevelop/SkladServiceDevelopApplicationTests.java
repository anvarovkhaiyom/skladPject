package com.example.skladservicedevelop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkladServiceDevelopApplicationTests {

    @Test
    void contextLoads() {
    }

}
